//
//  main.swift
//  feather
//
//  Created by samara on 5/17/24.
//

import UIKit
import func Foundation.NSStringFromClass

_ = UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(AppDelegate.self))
